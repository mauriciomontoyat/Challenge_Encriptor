Copy patch to install dir.
Run patch, select "Try to patch another with the amtib file (32-Bit)" and apply.